linkhost = '44.203.201.20'
EMAIL_PADRAO = f"Esse é seu codigo de ativacao: CODIGO <br> Você pode ativar sua conta em: http://{linkhost}/ativar/USUARIO/CODIGO"
EMAIL_RECOV = f"Esse é seu novo codigo de ativacao: CODIGO <br> Você pode ativar sua conta em: http://{linkhost}/ativar/USUARIO/CODIGO <br> Sua nova senha é: SENHA"
BANCO_DE_DADOS = "Banco de Dados/projetoEstoque.db"